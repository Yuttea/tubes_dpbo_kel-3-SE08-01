/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Transaksi;

import java.util.List;

/**
 *
 * @author ADVAN
 */
public class TampilPesanan {
 public static void tampilPesanan(List<String> daftarMenu) {
        System.out.println("\n=== Daftar Pesanan ===");
        if(daftarMenu.isEmpty()) {
            System.out.println("Belum ada pesanan!");
        } else {
            for(int i = 0; i < daftarMenu.size(); i++) {
                System.out.println((i+1) + ". " + daftarMenu.get(i));
                }
            }
        }    
    }   

