package Transaksi;

import java.util.ArrayList;
import java.util.Scanner;
import static aplikasi.Aplikasi.mainmenu; // pastikan method mainmenu() itu public static
import aplikasi.Aplikasi; 

public class Checkout {

    private static ArrayList<String> menuKopi = new ArrayList<>();

    public static void checkout() {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("\n=== Menu Kopi dan Teh ===");
            System.out.println("1. Kopi Cinta, Harga 5000");
            System.out.println("2. Kopi Sayang, Harga 5000");
            System.out.println("3. S The Red Flag, Harga 7000");
            System.out.println("4. S The Green Flag, Harga 7000");
            System.out.println("5. Daftar Pesanan");
            System.out.println("6. Keluar");
            System.out.print("Pilih Menu: ");

            int menukopi = Integer.parseInt(scanner.nextLine());

            switch (menukopi) {
                case 1:
                    menuKopi.add("Kopi Cinta");
                    break;
                case 2:
                    menuKopi.add("Kopi Sayang");
                    break;
                case 3:
                    menuKopi.add("S The Red Flag");
                    break;
                case 4:
                    menuKopi.add("S The Green Flag");
                    break;
                case 5:
                    TampilPesanan.tampilPesanan(menuKopi); 
                    break;
                case 6:
                    mainmenu(); 
                    return; 
                default:
                    System.out.println("Pilihan Tidak Valid!");
            }
        }
    }
}
