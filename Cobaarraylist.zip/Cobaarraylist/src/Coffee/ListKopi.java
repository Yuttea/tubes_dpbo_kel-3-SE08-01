/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Coffee;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author ADVAN
 */
public class ListKopi {
    private static List<MenuKopi> kopiList = new ArrayList<>();

    static {
        kopiList.add(new MenuKopi("Americano", 15000));
        kopiList.add(new MenuKopi("Latte", 18000));
        kopiList.add(new MenuKopi("Teh Manis", 8000));
    }

    public static void menuKopi(){
        System.out.println("\n=== Menu Kopi dan Teh ===");
        System.out.printf("%-5s %-15s %-10s\n", "No", "Jenis Minuman", "Harga");

        for(int i = 0; i < kopiList.size(); i++){
            MenuKopi coffee = kopiList.get(i);
            System.out.printf("%-5d %-15s Rp.%-10d\n", 
                (i+1), coffee.getKopi(), coffee.getHarga());
        }
    }
}
