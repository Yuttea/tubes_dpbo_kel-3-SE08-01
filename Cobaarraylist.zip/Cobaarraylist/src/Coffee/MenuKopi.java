package Coffee;

public class MenuKopi {
    private String kopi;
    private int harga;

    public MenuKopi(String kopi, int harga) {
        this.kopi = kopi;
        this.harga = harga;
    }

    public String getKopi() {
        return kopi;
    }

    public int getHarga() {
        return harga;
    }
}
