/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package User;

/**
 *
 * @author ADVAN
 */
public class InfoUser {
    public static void profil() {
        UserAccount user = Login.getUser(); 

        if (user != null) {
            System.out.println("\n=== Profil Pengguna ===");
            System.out.println("Username: " + user.getUsername());
            System.out.println("Profil: " + user.getProfil());
        } else {
            System.out.println("Belum ada user yang login.");
        }
    }
    }

