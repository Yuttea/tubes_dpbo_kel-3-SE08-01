/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package User;
import java.util.Scanner;
import java.util.List;
import java.util.ArrayList;
import static aplikasi.Aplikasi.mainmenu;

/**
 *
 * @author ADVAN
 */

public class Login {
    public static List<UserAccount> users = new ArrayList<>();
    public static UserAccount user; 

    public static void addUser(UserAccount newUser) {
        users.add(newUser);
    }
    
    public static UserAccount getUser() {
        return user;
    }

    public static void login() {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n=== Login ===");
            System.out.print("Username: ");
            String username = scanner.nextLine();
            System.out.print("Password: ");
            String password = scanner.nextLine();

            boolean isValid = false;

            for (int i = 0; i < users.size(); i++) {
                if (username.equals(users.get(i).getUsername()) &&
                    password.equals(users.get(i).getPassword())) {
                    user = users.get(i);
                    isValid = true;
                    break;
                }
            }

            if (isValid) {
                System.out.println("Login Berhasil");
                mainmenu(); // Menu utama
                break;
            } else {
                System.out.println("Username dan Password Invalid");
            }
            
        }
    }
}
