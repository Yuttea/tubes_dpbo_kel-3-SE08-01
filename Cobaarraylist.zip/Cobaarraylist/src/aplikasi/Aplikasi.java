package aplikasi;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import Coffee.ListKopi;
import User.UserAccount;
import User.Login;
import User.InfoUser;
import Transaksi.Checkout;

public class Aplikasi {
    private static List<UserAccount> users = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        // Tambahkan 1 user default
        users.add(new UserAccount("admin", "admin123", "Administrator"));
        
        // Simulasi daftar kopi (sebaiknya ini ada di Coffee.ListKopi)
        // ListKopi sudah mengatur daftarnya secara static

        // Kirim user ke class Login
        for (UserAccount user : users) {
            Login.addUser(user);
        }

        // Jalankan login
        Login.login();
    }

    public static void mainmenu() {
        while (true) {
            System.out.println("\n=== Main Menu ===");
            System.out.println("1. Profil Pengguna");
            System.out.println("2. Menu Kopi & Teh");
            System.out.println("3. Checkout");
            System.out.println("4. Logout");
            System.out.print("Pilih Menu: ");

            String input = scanner.nextLine();

            switch (input) {
                case "1":
                    InfoUser.profil();
                    break;

                case "2":
                    ListKopi.menuKopi();
                    break;

                case "3":
                    Checkout.checkout();
                    break;

                case "4":
                    Login.login(); 
                    return;

                default:
                    System.out.println("Pilihan tidak valid!");
            }
        }
    }
}
